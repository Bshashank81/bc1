package com.sample.financialgoaltracker;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class FinancialgoaltrackerApplicationTests {

	@Test
	void contextLoads() {
	}

}
