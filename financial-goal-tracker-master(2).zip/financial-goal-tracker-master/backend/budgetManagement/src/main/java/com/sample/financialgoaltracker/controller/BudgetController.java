package com.sample.financialgoaltracker.controller;

public class BudgetController {
}
